Para gerar exeutável, execute o comando: make
Para rodar o programa, execute o comando: ./scheduler
Para gerar executável com linhas de debug, execute o comando: make debug
Para remover arquivos gerados com execeção do executável, execute o comando: make clean
Para remover todos os arquivos gerados, execute o comando: make purge